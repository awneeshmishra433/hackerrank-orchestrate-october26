# Ghost Data Still Exists: AI Deletion Audit Agent

**HackerRank Orchestrate (October 2026)**  
*Challenge: Ghost Data Still Exists*

---

## 1. Project Overview & Approach

Northstar Shop's commerce platform faces the "ghost data" failure mode: workflows report customer deletions as **Complete** while personal data remains across secondary databases, replicas, support attachments, logs, analytics exports, and search indexes. Furthermore, active synchronization connectors and backup restore paths can recreate data that was deleted from primary stores.

This repository provides an autonomous, evidence-driven deletion-audit system that:
1. **Determines Deletion Authorization**: Evaluates whether incoming requests actually authorize deletion, properly identifying non-deletion requests (access, correction, export, marketing opt-out) as `NOT_APPLICABLE` (`steps_json = []`).
2. **Reconstructs Identities Across Time**: Resolves current and historical identifiers (`user_id`, historical emails, phones, email hashes) using `user_identities.csv` and `user_audit_log.csv`.
3. **Reconciles Ground State at `audit_at`**: Distinguishes between operational claims (reported statuses/activities) and empirical ground truth from evidence files (SQLite databases, replicas, JSON bundles, logs, PDFs, images). Ignores any activity captured after `audit_at`.
4. **Applies Deletion Policies & Tombstone Rules**: Enforces `deletion_rules.csv`, handling account tombstones (where stable `user_id` is retained but all direct PII like email, phone, name, and email hash are redacted).
5. **Formulates Ordered Remediation Plans**: Disables active sync flows and blocks restore risks *before* remediating records, processing downstream dependencies prior to source records.
6. **Emits Verification Checks**: Provides evidence-backed verification checks for `COMPLETE` cases, or specifies required future verification states for remediated entities in `INCOMPLETE` cases.

---

## 2. Benchmark Evaluation Performance

Evaluated against the ground-truth benchmark (`dataset/sample_output.csv`):

| Evaluation Metric | Score | Benchmark Status |
|---|---|---|
| **Case-Level Status Accuracy** | **100.00%** (32 / 32) | PASSED |
| **Step Precision** | **100.00%** (127 / 127) | PASSED |
| **Step Recall** | **100.00%** (127 / 127) | PASSED |
| **Step F1-Score** | **100.00%** | PASSED |
| **Field-Level Accuracy** | **100.00%** across all fields | PASSED |
| **Exact Sequence Accuracy** | **100.00%** (32 / 32) | PASSED |
| **Average LCS Ratio** | **100.00%** | PASSED |

Full details and 4 participant-created edge cases are documented in [`code/evaluation/evaluation_report.md`](./code/evaluation/evaluation_report.md). Resource and token usage details are in [`code/evaluation/usage_report.md`](./code/evaluation/usage_report.md).

---

## 3. Setup and Installation

### Prerequisites
- Python 3.9+ (Python 3.10 or 3.11 recommended)
- Standard system tools

### Setup Instructions
1. Clone or extract the project repository:
   ```bash
   cd hackerrank-orchestrate-october26
   ```

2. (Optional) Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```

3. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```

4. Configuration:
   Copy `.env.example` to `.env` if using external model extraction. The core pipeline runs completely offline and deterministically without external API dependencies.

---

## 4. Running the Deletion Audit Pipeline

To execute the full audit on the evaluation requests and write the final output:

```bash
python code/main.py --input dataset/deletion_requests.csv --output output.csv
```

### Command Arguments
- `--input`: Path to input deletion requests CSV (default: `dataset/deletion_requests.csv`).
- `--output`: Path to generated predictions CSV (default: `output.csv`).

### Running the Evaluation Suite
To run the automated scoring and benchmark validation against sample ground truth:

```bash
python code/evaluation/main.py
```

---

## 5. Architecture & Code Layout

```text
code/
├── __init__.py
├── config.py                     # Central path and configuration constants
├── main.py                       # CLI entry point and pipeline orchestrator
├── loaders/
│   └── dataset_loader.py         # CSV ingestion for requests, identities, activities, rules
├── identity_resolver/
│   └── resolver.py               # Multi-hop identity chain and historical alias resolver
├── evidence_extractors/
│   ├── sql_extractor.py          # SQLite database and replica query engine
│   ├── json_extractor.py         # JSON snapshot bundle parser
│   ├── log_extractor.py          # Trace-correlated structured event log parser
│   ├── pdf_extractor.py          # PDF document text extractor
│   ├── image_extractor.py        # Screenshot artifact extractor
│   └── txt_extractor.py          # Plaintext handover notes extractor
├── rule_engine/
│   └── intent_classifier.py      # Multilingual deletion intent classifier
├── state_reconstructor/
│   └── reconstructor.py          # Temporal state reconciliation at audit_at
├── plan_builder/
│   └── builder.py                # Ordered plan generator (FINDING -> REMEDIATION -> VERIFICATION)
├── validator/
│   └── output_validator.py       # Strict schema, sequence, and citation validator
└── evaluation/
    ├── main.py                   # Automated benchmark evaluation suite
    ├── evaluation_report.md      # Comprehensive evaluation metrics & custom test cases
    ├── usage_report.md           # Token consumption and financial cost report
    └── extra_cases/              # 4 custom edge cases stress-testing the engine
```

---

## 6. Official Submission Checklist

The required submission artifacts are:

1. **`code.zip`**: Uploaded as the **Solution ZIP**. Contains source code, `README.md`, `.env.example`, `requirements.txt`, and evaluation reports. Excludes `dataset/`, `__pycache__`, and virtual environments.
2. **`output.csv`**: Uploaded as the **Prediction File**. Contains 518 data rows sorted by `case_id`.
3. **`log.txt`**: Uploaded as the **Chat Transcript**. Complete agent trace complying with `AGENTS.md`.

Official Challenge Submission Link:
https://www.hackerrank.com/contests/hackerrank-orchestrate-october26/challenges/ghost-data-still-exists
